<?php
header('Content-Type: application/json');
require_once 'db_connection.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

switch ($method) {
    case 'GET':
        if (isset($_GET['action'])) {
            switch ($_GET['action']) {
                case 'get_users':
                    $sql = "SELECT Id_Usuario, Nombre, Correo, Descripcion, Imagen_Perfil FROM usuarios";
                    $result = $conn->query($sql);
                    $users = [];
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            $users[] = $row;
                        }
                    }
                    echo json_encode(['success' => true, 'data' => $users]);
                    break;

                case 'get_exercises':
                    $sql = "SELECT Id_Ejercicio, Musculo_Objetivo, Nombre_Ejercicio FROM ejercicios ORDER BY Musculo_Objetivo, Nombre_Ejercicio";
                    $result = $conn->query($sql);
                    $exercises = [];
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            $exercises[] = $row;
                        }
                    }
                    echo json_encode(['success' => true, 'data' => $exercises]);
                    break;

                case 'get_routines_by_user':
                    if (isset($_GET['Id_Usuario'])) {
                        $id_usuario = (int)$_GET['Id_Usuario'];
                        $stmt = $conn->prepare("SELECT Id_Rutina, Nombre, Descripcion_Rutina FROM rutinas WHERE Id_Usuario = ?");
                        $stmt->bind_param("i", $id_usuario);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        $routines = [];
                        while($row = $result->fetch_assoc()) {
                            $routines[] = $row;
                        }
                        echo json_encode(['success' => true, 'data' => $routines]);
                    } else {
                        echo json_encode(['success' => false, 'message' => 'Id_Usuario no proporcionado.']);
                    }
                    break;

                case 'get_routine_details':
                    if (isset($_GET['Id_Rutina'])) {
                        $id_rutina = (int)$_GET['Id_Rutina'];
                        $stmt = $conn->prepare("
                            SELECT re.Series, re.Repeticiones, re.Factor_Intensidad, re.Calentamiento, re.Orden,
                                   e.Nombre_Ejercicio, e.Musculo_Objetivo
                            FROM rutina_ejercicios re
                            JOIN ejercicios e ON re.Id_Ejercicio = e.Id_Ejercicio
                            WHERE re.Id_Rutina = ?
                            ORDER BY re.Orden
                        ");
                        $stmt->bind_param("i", $id_rutina);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        $details = [];
                        while($row = $result->fetch_assoc()) {
                            $details[] = $row;
                        }
                        echo json_encode(['success' => true, 'data' => $details]);
                    } else {
                        echo json_encode(['success' => false, 'message' => 'Id_Rutina no proporcionado.']);
                    }
                    break;

                default:
                    echo json_encode(['success' => false, 'message' => 'Acción GET no reconocida.']);
                    break;
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Acción no especificada para GET.']);
        }
        break;

    case 'POST':
        if (isset($input['action'])) {
            switch ($input['action']) {
                case 'register_user':
                    $nombre = $input['Nombre'] ?? '';
                    $correo = $input['Correo'] ?? '';
                    $contra = $input['Contra'] ?? ''; 
                    $descripcion = $input['Descripcion'] ?? '';
                    $imagen_perfil = $input['Imagen_Perfil'] ?? '';


                    if (!empty($nombre) && !empty($correo) && !empty($contra)) {
                        $hashed_password = password_hash($contra, PASSWORD_DEFAULT);

                        $stmt = $conn->prepare("INSERT INTO usuarios (Nombre, Correo, Contra, Descripcion, Imagen_Perfil) VALUES (?, ?, ?, ?, ?)");
                        $stmt->bind_param("sssss", $nombre, $correo, $hashed_password, $descripcion, $imagen_perfil);

                        if ($stmt->execute()) {
                            echo json_encode(['success' => true, 'message' => 'Usuario registrado exitosamente.', 'Id_Usuario' => $conn->insert_id]);
                        } else {
                            echo json_encode(['success' => false, 'message' => 'Error al registrar usuario: ' . $stmt->error]);
                        }
                        $stmt->close();
                    } else {
                        echo json_encode(['success' => false, 'message' => 'Datos incompletos para registrar usuario.']);
                    }
                    break;

                case 'login_user':
                    $correo = $input['Correo'] ?? '';
                    $contra = $input['Contra'] ?? '';

                    if (!empty($correo) && !empty($contra)) {
                        $stmt = $conn->prepare("SELECT Id_Usuario, Nombre, Correo, Contra, Descripcion, Imagen_Perfil FROM usuarios WHERE Correo = ?");
                        $stmt->bind_param("s", $correo);
                        $stmt->execute();
                        $result = $stmt->get_result();

                        if ($result->num_rows > 0) {
                            $user = $result->fetch_assoc();

                            if (password_verify($contra, $user['Contra'])) {

                                unset($user['Contra']);
                                echo json_encode(['success' => true, 'message' => 'Inicio de sesión exitoso.', 'user' => $user]);
                            } else {
                                echo json_encode(['success' => false, 'message' => 'Contraseña incorrecta.']);
                            }
                        } else {
                            echo json_encode(['success' => false, 'message' => 'Correo no encontrado.']);
                        }
                        $stmt->close();
                    } else {
                        echo json_encode(['success' => false, 'message' => 'Correo y contraseña son requeridos.']);
                    }
                    break;

                case 'create_routine':
                    $id_usuario = $input['Id_Usuario'] ?? null;
                    $nombre_rutina = $input['Nombre'] ?? '';
                    $descripcion_rutina = $input['Descripcion_Rutina'] ?? '';
                    $ejercicios_rutina = $input['Ejercicios'] ?? [];

                    if (!empty($id_usuario) && !empty($nombre_rutina) && !empty($ejercicios_rutina)) {

                        $stmt = $conn->prepare("INSERT INTO rutinas (Id_Usuario, Nombre, Descripcion_Rutina) VALUES (?, ?, ?)");
                        $stmt->bind_param("iss", $id_usuario, $nombre_rutina, $descripcion_rutina);

                        if ($stmt->execute()) {
                            $id_rutina_nueva = $conn->insert_id;


                            $stmt_ejercicio = $conn->prepare("INSERT INTO rutina_ejercicios (Id_Rutina, Id_Ejercicio, Series, Repeticiones, Factor_Intensidad, Calentamiento, Orden) VALUES (?, ?, ?, ?, ?, ?, ?)");
                            foreach ($ejercicios_rutina as $ejercicio) {
                                $stmt_ejercicio->bind_param("iiiiisi",
                                    $id_rutina_nueva,
                                    $ejercicio['Id_Ejercicio'],
                                    $ejercicio['Series'],
                                    $ejercicio['Repeticiones'],
                                    $ejercicio['Factor_Intensidad'],
                                    $ejercicio['Calentamiento'],
                                    $ejercicio['Orden']
                                );
                                $stmt_ejercicio->execute();
                            }
                            $stmt_ejercicio->close();

                            echo json_encode(['success' => true, 'message' => 'Rutina creada exitosamente.', 'Id_Rutina' => $id_rutina_nueva]);
                        } else {
                            echo json_encode(['success' => false, 'message' => 'Error al crear rutina: ' . $stmt->error]);
                        }
                        $stmt->close();
                    } else {
                        echo json_encode(['success' => false, 'message' => 'Datos incompletos para crear rutina.']);
                    }
                    break;

                default:
                    echo json_encode(['success' => false, 'message' => 'Acción POST no reconocida.']);
                    break;
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Acción no especificada para POST.']);
        }
        break;

    case 'DELETE':
        if (isset($input['action']) && $input['action'] == 'delete_routine') {
            $id_rutina = $input['Id_Rutina'] ?? null;

            if (!empty($id_rutina)) {

                $stmt_ejercicios = $conn->prepare("DELETE FROM rutina_ejercicios WHERE Id_Rutina = ?");
                $stmt_ejercicios->bind_param("i", $id_rutina);
                $stmt_ejercicios->execute();
                $stmt_ejercicios->close();


                $stmt_rutina = $conn->prepare("DELETE FROM rutinas WHERE Id_Rutina = ?");
                $stmt_rutina->bind_param("i", $id_rutina);

                if ($stmt_rutina->execute()) {
                    if ($stmt_rutina->affected_rows > 0) {
                        echo json_encode(['success' => true, 'message' => 'Rutina eliminada exitosamente.']);
                    } else {
                        echo json_encode(['success' => false, 'message' => 'Rutina no encontrada.']);
                    }
                } else {
                    echo json_encode(['success' => false, 'message' => 'Error al eliminar rutina: ' . $stmt_rutina->error]);
                }
                $stmt_rutina->close();
            } else {
                echo json_encode(['success' => false, 'message' => 'Id_Rutina no proporcionado para eliminar.']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Acción DELETE no reconocida o no especificada.']);
        }
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Método no soportado.']);
        break;
}

$conn->close();
?>