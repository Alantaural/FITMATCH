
document.addEventListener('DOMContentLoaded', () => {

    const globalMessage = document.getElementById('global-message');
    const authSection = document.getElementById('auth-section');
    const loggedInStatus = document.getElementById('logged-in-status');
    const usernameDisplay = document.getElementById('username-display');
    const logoutButton = document.getElementById('logout-button');
    const authForms = document.getElementById('auth-forms');

    const loginForm = document.getElementById('login-form');
    const loginMessage = document.getElementById('login-message');
    const registerForm = document.getElementById('register-form');
    const registerMessage = document.getElementById('register-message');

    const createRoutineSection = document.getElementById('create-routine-section');
    const createRoutineForm = document.getElementById('create-routine-form');
    const routineNameInput = document.getElementById('routine-name');
    const routineDescriptionInput = document.getElementById('routine-description');
    const createRoutineMessage = document.getElementById('create-routine-message');

    const exerciseSelect = document.getElementById('exercise-select');
    const exerciseSeriesInput = document.getElementById('exercise-series');
    const exerciseRepsInput = document.getElementById('exercise-reps');
    const exerciseIntensityInput = document.getElementById('exercise-intensity');
    const exerciseWarmupInput = document.getElementById('exercise-warmup');
    const addExerciseButton = document.getElementById('add-exercise-button');
    const currentRoutineExercisesList = document.getElementById('current-routine-exercises');

    const myRoutinesSection = document.getElementById('my-routines-section');
    const myRoutinesList = document.getElementById('my-routines-list');
    const routineDetailsViewer = document.getElementById('routine-details-viewer');
    const routineDetailName = document.getElementById('routine-detail-name');
    const routineDetailDescription = document.getElementById('routine-detail-description');
    const routineDetailsList = document.getElementById('routine-details-list');
    const backToRoutinesButton = document.getElementById('back-to-routines-button');



    let currentUser = null; 
    let exercisesData = [];
    let currentRoutineExercises = []; 


    function showMessage(element, message, type) {
        element.textContent = message;
        element.className = `form-message ${type}`;
        element.style.display = 'block';
    }

    function hideMessage(element) {
        element.style.display = 'none';
        element.textContent = '';
    }


function checkLoginStatus() {
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    const username = localStorage.getItem('username');

    if (isLoggedIn === 'true' && username) {
        document.getElementById('auth-section').style.display = 'none';
        document.getElementById('logged-in-status').style.display = 'block';
        document.getElementById('username-display').textContent = username;
        document.getElementById('create-routine-section').style.display = 'block';
        document.getElementById('my-routines-section').style.display = 'none'; 
        showGlobalMessage('¡Sesión iniciada correctamente!', 'success');
    } else {
        document.getElementById('auth-section').style.display = 'block';
        document.getElementById('logged-in-status').style.display = 'none';
        document.getElementById('create-routine-section').style.display = 'none';
        document.getElementById('my-routines-section').style.display = 'none';

    }
}


document.addEventListener('DOMContentLoaded', () => {

    const logoutButton = document.getElementById('logout-button');
    if (logoutButton) { 
        logoutButton.addEventListener('click', () => {
            localStorage.removeItem('isLoggedIn');
            localStorage.removeItem('username');
            localStorage.removeItem('authToken'); 

            
            document.getElementById('auth-section').style.display = 'block';
            document.getElementById('logged-in-status').style.display = 'none';
            document.getElementById('create-routine-section').style.display = 'none';
            document.getElementById('my-routines-section').style.display = 'none'; 

            showGlobalMessage('¡Sesión cerrada con éxito!', 'success');

        });
    }



    checkLoginStatus(); 
});



    function updateUIForLoggedInUser() {
        authSection.style.display = 'none';
        loggedInStatus.style.display = 'block';
        usernameDisplay.textContent = currentUser.Nombre;
        createRoutineSection.style.display = 'block';
        myRoutinesSection.style.display = 'block';
        loadUserRoutines(currentUser.Id_Usuario); 
        loadExercisesForRoutineCreation(); 
    }

    function updateUIForLoggedOutUser() {
        authSection.style.display = 'block';
        loggedInStatus.style.display = 'none';
        usernameDisplay.textContent = '';
        createRoutineSection.style.display = 'none';
        myRoutinesSection.style.display = 'none';
        myRoutinesList.innerHTML = ''; 
        currentRoutineExercisesList.innerHTML = '';
        routineDetailsViewer.style.display = 'none';
        authForms.style.display = 'block'; 
    }


    async function apiRequest(endpoint, method = 'GET', data = null) {
        try {
            const options = {
                method: method,
                headers: {
                    'Content-Type': 'application/json'
                }
            };
            if (data) {
                options.body = JSON.stringify(data);
            }

            const response = await fetch(`http://localhost:8080/api.php${endpoint}`, options);
            const result = await response.json();
            return result;
        } catch (error) {
            console.error('Error en la petición API:', error);
            showMessage(globalMessage, 'Error de conexión con el servidor.', 'error');
            return { success: false, message: 'Error de red.' };
        }
    }


    loginForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        hideMessage(loginMessage);

        const formData = new FormData(loginForm);
        const data = Object.fromEntries(formData.entries());
        data.action = 'login_user';

        const result = await apiRequest('', 'POST', data); 

        if (result.success) {
            currentUser = result.user;
            localStorage.setItem('fitmatchUser', JSON.stringify(currentUser));
            showMessage(loginMessage, result.message, 'success');
            loginForm.reset();
            updateUIForLoggedInUser();
        } else {
            showMessage(loginMessage, result.message, 'error');
        }
    });

    registerForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        hideMessage(registerMessage);

        const formData = new FormData(registerForm);
        const data = Object.fromEntries(formData.entries());
        data.action = 'register_user';

        const result = await apiRequest('', 'POST', data);

        if (result.success) {
            showMessage(registerMessage, result.message + ' Ahora puedes iniciar sesión.', 'success');
            registerForm.reset();
        } else {
            showMessage(registerMessage, result.message, 'error');
        }
    });

    logoutButton.addEventListener('click', () => {
        currentUser = null;
        localStorage.removeItem('fitmatchUser'); 
        showMessage(globalMessage, 'Has cerrado sesión.', 'success');
        updateUIForLoggedOutUser();
    });


    async function loadExercisesForRoutineCreation() {
        const result = await apiRequest('?action=get_exercises', 'GET');
        if (result.success) {
            exercisesData = result.data;
            exerciseSelect.innerHTML = '<option value="">-- Selecciona un ejercicio --</option>';
            exercisesData.forEach(exercise => {
                const option = document.createElement('option');
                option.value = exercise.Id_Ejercicio;
                option.textContent = `${exercise.Nombre_Ejercicio} (${exercise.Musculo_Objetivo})`;
                exerciseSelect.appendChild(option);
            });
        } else {
            console.error('Error al cargar ejercicios:', result.message);
            showMessage(createRoutineMessage, 'No se pudieron cargar los ejercicios.', 'error');
        }
    }

    addExerciseButton.addEventListener('click', () => {
        const idEjercicio = exerciseSelect.value;
        const series = parseInt(exerciseSeriesInput.value);
        const repeticiones = parseInt(exerciseRepsInput.value);
        const factorIntensidad = exerciseIntensityInput.value.trim();
        const calentamiento = parseInt(exerciseWarmupInput.value);

        if (!idEjercicio || isNaN(series) || isNaN(repeticiones) || factorIntensidad === '' || isNaN(calentamiento)) {
            showMessage(createRoutineMessage, 'Por favor, completa todos los campos del ejercicio.', 'error');
            return;
        }

        const selectedExercise = exercisesData.find(ex => ex.Id_Ejercicio == idEjercicio);
        if (!selectedExercise) {
            showMessage(createRoutineMessage, 'Ejercicio no válido seleccionado.', 'error');
            return;
        }

        const newExerciseEntry = {
            Id_Ejercicio: idEjercicio,
            Nombre_Ejercicio: selectedExercise.Nombre_Ejercicio,
            Musculo_Objetivo: selectedExercise.Musculo_Objetivo,
            Series: series,
            Repeticiones: repeticiones,
            Factor_Intensidad: factorIntensidad,
            Calentamiento: calentamiento,
            Orden: currentRoutineExercises.length + 1 
        };

        currentRoutineExercises.push(newExerciseEntry);
        renderCurrentRoutineExercises();
        showMessage(createRoutineMessage, 'Ejercicio añadido temporalmente.', 'success');

        exerciseSelect.value = '';
        exerciseSeriesInput.value = '';
        exerciseRepsInput.value = '';
        exerciseIntensityInput.value = '';
        exerciseWarmupInput.value = '';
    });

    function renderCurrentRoutineExercises() {
        currentRoutineExercisesList.innerHTML = '';
        if (currentRoutineExercises.length === 0) {
            currentRoutineExercisesList.innerHTML = '<li>No hay ejercicios añadidos a esta rutina.</li>';
            return;
        }
        currentRoutineExercises.sort((a, b) => a.Orden - b.Orden); 
        currentRoutineExercises.forEach((exercise, index) => {
            const listItem = document.createElement('li');
            listItem.innerHTML = `
                <span>
                    ${exercise.Orden}. <strong>${exercise.Nombre_Ejercicio}</strong> (${exercise.Musculo_Objetivo}) -
                    Series: ${exercise.Series}, Reps: ${exercise.Repeticiones}, Intensidad: ${exercise.Factor_Intensidad}, Calentamiento: ${exercise.Calentamiento}
                </span>
                <button data-index="${index}" class="remove-temp-exercise">X</button>
            `;
            currentRoutineExercisesList.appendChild(listItem);
        });


        document.querySelectorAll('.remove-temp-exercise').forEach(button => {
            button.addEventListener('click', (event) => {
                const indexToRemove = parseInt(event.target.dataset.index);
                currentRoutineExercises.splice(indexToRemove, 1);

                currentRoutineExercises.forEach((ex, idx) => ex.Orden = idx + 1);
                renderCurrentRoutineExercises();
                showMessage(createRoutineMessage, 'Ejercicio eliminado de la lista temporal.', 'success');
            });
        });
    }


    createRoutineForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        hideMessage(createRoutineMessage);

        if (!currentUser) {
            showMessage(createRoutineMessage, 'Debes iniciar sesión para crear una rutina.', 'error');
            return;
        }

        if (currentRoutineExercises.length === 0) {
            showMessage(createRoutineMessage, 'Añade al menos un ejercicio a la rutina.', 'error');
            return;
        }

        const routineData = {
            action: 'create_routine',
            Id_Usuario: currentUser.Id_Usuario,
            Nombre: routineNameInput.value.trim(),
            Descripcion_Rutina: routineDescriptionInput.value.trim(),
            Ejercicios: currentRoutineExercises 
        };

        const result = await apiRequest('', 'POST', routineData);

        if (result.success) {
            showMessage(createRoutineMessage, result.message, 'success');
            createRoutineForm.reset();
            currentRoutineExercises = [];
            renderCurrentRoutineExercises();
            loadUserRoutines(currentUser.Id_Usuario);
        } else {
            showMessage(createRoutineMessage, result.message, 'error');
        }
    });

    async function loadUserRoutines(userId) {
        if (!userId) return;
        myRoutinesList.innerHTML = '<li>Cargando tus rutinas...</li>';
        const result = await apiRequest(`?action=get_routines_by_user&Id_Usuario=${userId}`, 'GET');
        if (result.success) {
            myRoutinesList.innerHTML = '';
            if (result.data.length === 0) {
                myRoutinesList.innerHTML = '<li>No has creado ninguna rutina aún.</li>';
                return;
            }
            result.data.forEach(routine => {
                const listItem = document.createElement('li');
                listItem.classList.add('routine-item');
                listItem.innerHTML = `
                    <span>
                        <strong>${routine.Nombre}</strong>: ${routine.Descripcion_Rutina || 'Sin descripción'}
                    </span>
                    <div>
                        <button class="view-routine-button" data-id="${routine.Id_Rutina}">Ver</button>
                        <button class="delete-routine-button" data-id="${routine.Id_Rutina}">Eliminar</button>
                    </div>
                `;
                myRoutinesList.appendChild(listItem);
            });
            attachRoutineEventListeners();
        } else {
            myRoutinesList.innerHTML = `<li>Error al cargar rutinas: ${result.message}</li>`;
            console.error('Error al cargar rutinas:', result.message);
        }
    }

    function attachRoutineEventListeners() {
        document.querySelectorAll('.view-routine-button').forEach(button => {
            button.addEventListener('click', async (event) => {
                const routineId = event.target.dataset.id;
                const routineName = event.target.closest('.routine-item').querySelector('strong').textContent;
                const routineDesc = event.target.closest('.routine-item').querySelector('span').textContent.split(': ')[1];

                routineDetailName.textContent = routineName;
                routineDetailDescription.textContent = routineDesc;

                const result = await apiRequest(`?action=get_routine_details&Id_Rutina=${routineId}`, 'GET');
                if (result.success) {
                    routineDetailsList.innerHTML = '';
                    if (result.data.length === 0) {
                        routineDetailsList.innerHTML = '<li>Esta rutina no tiene ejercicios.</li>';
                    } else {
                        result.data.forEach(detail => {
                            const listItem = document.createElement('li');
                            listItem.textContent = `${detail.Orden}. ${detail.Nombre_Ejercicio} (${detail.Musculo_Objetivo}) - Series: ${detail.Series}, Reps: ${detail.Repeticiones}, Intensidad: ${detail.Factor_Intensidad}, Calentamiento: ${detail.Calentamiento}`;
                            routineDetailsList.appendChild(listItem);
                        });
                    }
                    myRoutinesList.style.display = 'none';
                    routineDetailsViewer.style.display = 'block';
                } else {
                    showMessage(globalMessage, 'Error al cargar detalles de la rutina: ' + result.message, 'error');
                }
            });
        });

        document.querySelectorAll('.delete-routine-button').forEach(button => {
            button.addEventListener('click', async (event) => {
                const routineId = event.target.dataset.id;
                if (confirm('¿Estás seguro de que quieres eliminar esta rutina?')) {
                    const result = await apiRequest('', 'DELETE', { action: 'delete_routine', Id_Rutina: routineId });
                    if (result.success) {
                        showMessage(globalMessage, result.message, 'success');
                        loadUserRoutines(currentUser.Id_Usuario); 
                    } else {
                        showMessage(globalMessage, result.message, 'error');
                    }
                }
            });
        });
    }

    backToRoutinesButton.addEventListener('click', () => {
        routineDetailsViewer.style.display = 'none';
        myRoutinesList.style.display = 'block';
    });



    checkLoginStatus(); 
});