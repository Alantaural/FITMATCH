-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 09-06-2025 a las 00:39:53
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `fitmatch`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ejercicios`
--

CREATE TABLE `ejercicios` (
  `Id_Ejercicio` int(10) NOT NULL,
  `Musculo_Objetivo` varchar(50) NOT NULL,
  `Nombre_Ejercicio` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ejercicios`
--

INSERT INTO `ejercicios` (`Id_Ejercicio`, `Musculo_Objetivo`, `Nombre_Ejercicio`) VALUES
(1, 'Pecho', 'Press Banca'),
(2, 'Pecho', 'Peck Deck en Polea'),
(3, 'Pecho', 'Press inclinado con mancuernas'),
(4, 'Pecho', 'Peck Deck en maquina'),
(5, 'Pecho', 'Press banca inclinado'),
(6, 'Pecho', 'Lagartijas'),
(7, 'Pecho', 'Fondos'),
(8, 'Pecho', 'Press banca declinado'),
(9, 'Pecho', 'Press banca declinado con mancuernas'),
(10, 'Pecho', 'Aperturas con mancuernas'),
(11, 'Espalda', 'Remo con barra'),
(12, 'Espalda', 'Remo en polea'),
(13, 'Espalda', 'Remo en maquina'),
(14, 'Espalda', 'Peso muerto'),
(15, 'Espalda', 'Dominadas'),
(16, 'Espalda', 'Peso muerto rumano'),
(17, 'Espalda', 'Remo con mancuernas'),
(18, 'Espalda', 'Jalon al pecho en polea'),
(19, 'Espalda', 'Buenos dias'),
(20, 'Espalda', 'Remo en polea con agarre cerrado'),
(21, 'Espalda', 'Remo unilateral en polea'),
(22, 'Espalda', 'Encogimiento de hombros con mancuernas'),
(23, 'Hombro', 'Press Militar con Barra (Sentado)'),
(24, 'Hombro', 'Press Militar con Mancuernas (De pie)'),
(25, 'Hombro', 'Elevaciones Laterales con Mancuernas'),
(26, 'Hombro', 'Elevaciones Frontales con Mancuernas'),
(27, 'Hombro', 'Face Pull'),
(28, 'Hombro', 'Pájaros con Mancuernas (Deltoides Posterior)'),
(29, 'Hombro', 'Press Arnold'),
(30, 'Triceps', 'Press Francés con Barra Z'),
(31, 'Triceps', 'Extensiones de Tríceps en Polea Alta (Cuerda)'),
(32, 'Triceps', 'Extensiones de Tríceps con Mancuerna a una mano'),
(33, 'Triceps', 'Fondos en Paralelas (Tríceps)'),
(34, 'Triceps', 'Patada de Tríceps con Mancuerna'),
(35, 'Triceps', 'Pushdown de Tríceps (Barra recta)'),
(36, 'Biceps', 'Curl de Bíceps con Barra'),
(37, 'Biceps', 'Curl de Bíceps con Mancuernas (Alterno)'),
(38, 'Biceps', 'Curl Martillo con Mancuernas'),
(39, 'Biceps', 'Curl Concentrado'),
(40, 'Biceps', 'Curl Predicador con Barra Z'),
(41, 'Biceps', 'Curl en Banco Inclinado con Mancuernas'),
(42, 'Antebrazo', 'Curl de Muñeca con Barra (Palma arriba)'),
(43, 'Antebrazo', 'Curl de Muñeca Inverso con Barra (Palma abajo)'),
(44, 'Antebrazo', 'Curl de Muñeca con Mancuerna (Sentado)'),
(45, 'Antebrazo', 'Agarre con Barra (Sostener peso)'),
(46, 'Pierna', 'Sentadilla con Barra (Back Squat)'),
(47, 'Pierna', 'Prensa de Piernas'),
(48, 'Pierna', 'Zancadas con Mancuernas'),
(49, 'Pierna', 'Extensiones de Cuádriceps en Máquina'),
(50, 'Pierna', 'Femoral Tumbado en Máquina (Curl de Isquiotibiales'),
(51, 'Pierna', 'Peso Muerto Rumano (RDL)'),
(52, 'Pierna', 'Sentadilla Búlgara'),
(53, 'Pierna', 'Gemelos de pie en Máquina'),
(54, 'Pierna', 'Gemelos Sentado en Máquina'),
(55, 'Gluteo', 'Hip Thrust con Barra'),
(56, 'Gluteo', 'Patada de Glúteo en Polea Baja'),
(57, 'Gluteo', 'Abducciones en Máquina'),
(58, 'Gluteo', 'Sentadilla Sumo con Mancuerna'),
(59, 'Gluteo', 'Puente de Glúteos'),
(60, 'Gluteo', 'Zancadas Laterales'),
(61, 'Abdomen', 'Crunch Abdominal'),
(62, 'Abdomen', 'Elevación de Piernas Colgado'),
(63, 'Abdomen', 'Plancha Abdominal'),
(64, 'Abdomen', 'Giros Rusos con Peso'),
(65, 'Abdomen', 'Abdominales Bicicleta'),
(66, 'Abdomen', 'Crunch Inverso'),
(67, 'Abdomen', 'Rueda Abdominal (Ab Wheel Rollout)');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rutinas`
--

CREATE TABLE `rutinas` (
  `Id_Rutina` int(10) NOT NULL,
  `Id_Usuario` int(10) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Descripcion_Rutina` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `rutinas`
--

INSERT INTO `rutinas` (`Id_Rutina`, `Id_Usuario`, `Nombre`, `Descripcion_Rutina`) VALUES
(1, 1, 'Alan Tristan', 'El PPL clásico de toda la fokin vida'),
(2, 3, 'pushpulleg', 'empuje jalon pierna'),
(3, 5, 'upper lower', 'la primera seccion sera de torso, la segunda de pierna'),
(4, 6, 'ppl', 'empuje jalon pierna, se separa por dias dependiendo los tipos de ejercicios'),
(5, 6, 'PIERNAGOD', 'PIERNAGODDDDDDD');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rutina_ejercicios`
--

CREATE TABLE `rutina_ejercicios` (
  `Id_Rutina` int(10) NOT NULL,
  `Id_Ejercicio` int(10) NOT NULL,
  `Series` int(10) NOT NULL,
  `Repeticiones` int(10) NOT NULL,
  `Factor_Intensidad` varchar(10) NOT NULL,
  `Calentamiento` int(10) NOT NULL,
  `Orden` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `rutina_ejercicios`
--

INSERT INTO `rutina_ejercicios` (`Id_Rutina`, `Id_Ejercicio`, `Series`, `Repeticiones`, `Factor_Intensidad`, `Calentamiento`, `Orden`) VALUES
(1, 1, 2, 8, 'Rir 1', 2, 1),
(1, 2, 2, 8, 'Rir 0', 1, 2),
(2, 19, 2, 10, '0', 2, 1),
(3, 1, 2, 8, '0', 2, 1),
(3, 18, 2, 8, '0', 1, 2),
(4, 1, 2, 10, '0', 2, 1),
(4, 2, 2, 10, '1', 1, 2),
(4, 18, 2, 10, '0', 1, 3),
(4, 14, 8, 20, '0', 0, 4),
(5, 6, 1, 1, '1', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `Id_Usuario` int(10) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Correo` varchar(50) NOT NULL,
  `Contra` varchar(255) NOT NULL,
  `Descripcion` varchar(200) NOT NULL,
  `Imagen_Perfil` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`Id_Usuario`, `Nombre`, `Correo`, `Contra`, `Descripcion`, `Imagen_Perfil`) VALUES
(1, 'Alan Tristan', 'at.briseno23@info.uas.edu.mx', 'Persistente.44R', 'Me llamo Alan y levanto 120 en banca', ''),
(2, 'pedro', 'at.briseno24@info.uas.edu.mx', '$2y$10$yeDRp4OsVkjapOH.RiyE8OfxjX62Ro1j1eK/hpH69DAt5wVeWK95G', 'a', ''),
(3, 'pedro', 'pedro@gmail.com', '$2y$10$LLBmxcZfGSiQFmxg23d.Ce1V7K3fKLJQyYt9WuvgVynr/v3fR43Ny', 'pedropedro', ''),
(4, 'Alan Tristan', 'at.briseno23@info.uas.edu.mx', '$2y$10$DQe82tZzqW8LqGvJxdc2I.uAHG2ktyTWBQA8rErr0c/7dhaTBTHpe', 'ola soy Alan levanto 120 en banca', ''),
(5, 'ola', 'ola@gmail.com', '$2y$10$wWGHfYuSabAIXOPn9ku1Mew8FfVHUw7wUDlk.4yC/b0YxJ.d8Iwo6', 'olaolaola', ''),
(6, 'taladan', 'taladan@gmail.com', '$2y$10$sK8dPn4qmY/lrvvh4KR7De9nesquQwVb71xeabHPH/G6/Eg7fb6va', 'soy un pendejo no puedo dejar de comer pan no me gusta el cardio y mi pr en banca es el de un niño chiquito', '');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `ejercicios`
--
ALTER TABLE `ejercicios`
  ADD PRIMARY KEY (`Id_Ejercicio`);

--
-- Indices de la tabla `rutinas`
--
ALTER TABLE `rutinas`
  ADD PRIMARY KEY (`Id_Rutina`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`Id_Usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `ejercicios`
--
ALTER TABLE `ejercicios`
  MODIFY `Id_Ejercicio` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT de la tabla `rutinas`
--
ALTER TABLE `rutinas`
  MODIFY `Id_Rutina` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `Id_Usuario` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
